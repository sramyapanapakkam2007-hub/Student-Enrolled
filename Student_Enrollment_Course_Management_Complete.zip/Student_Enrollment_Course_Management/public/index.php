<?php require_once 'includes.php'; headerHtml('Home'); ?>
<div class="hero text-center">
<h1 class="display-5 fw-bold">Student Enrollment & Course Management</h1>
<p class="lead">Manage students, courses and enrollments in one simple system.</p>
<a href="register.php" class="btn btn-primary btn-lg">Student Registration</a>
<a href="admin_login.php" class="btn btn-outline-dark btn-lg">Admin Login</a>
</div>
<div class="row g-4">
<div class="col-md-4"><div class="card p-4"><h4>Student Management</h4><p>Create an account and maintain student information.</p></div></div>
<div class="col-md-4"><div class="card p-4"><h4>Course Management</h4><p>View available courses, credits, faculty and capacity.</p></div></div>
<div class="col-md-4"><div class="card p-4"><h4>Enrollment</h4><p>Enroll in courses and track enrollment status.</p></div></div>
</div>
<?php footerHtml(); ?>
