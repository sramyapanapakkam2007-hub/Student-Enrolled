<?php require_once 'includes.php'; requireStudent();
$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare("SELECT * FROM courses WHERE course_id=?"); $stmt->execute([$id]); $course=$stmt->fetch();
if(!$course){ header('Location: courses.php'); exit; }
try{
    $stmt=$pdo->prepare("INSERT INTO enrollments(student_id,course_id,status) VALUES(?,?, 'Approved')");
    $stmt->execute([$_SESSION['student_id'],$id]);
} catch(PDOException $e) {}
header('Location: my_enrollments.php'); exit;
