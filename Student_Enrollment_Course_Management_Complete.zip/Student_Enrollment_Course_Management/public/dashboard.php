<?php require_once 'includes.php'; requireStudent();
$stmt=$pdo->prepare("SELECT * FROM students WHERE student_id=?"); $stmt->execute([$_SESSION['student_id']]); $student=$stmt->fetch();
$stmt=$pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE student_id=?"); $stmt->execute([$student['student_id']]); $count=$stmt->fetchColumn();
headerHtml('Student Dashboard');
?>
<h2>Welcome, <?=e($student['name'])?></h2>
<div class="row g-4 mt-1">
<div class="col-md-4"><div class="card p-4"><div class="stat"><?=e($count)?></div><div>Enrolled Courses</div></div></div>
<div class="col-md-8"><div class="card p-4"><h5>Profile</h5><p><b>Email:</b> <?=e($student['email'])?></p><p><b>Department:</b> <?=e($student['department'])?></p><p><b>Year:</b> <?=e($student['year_level'])?></p><a href="courses.php" class="btn btn-primary">Browse Courses</a></div></div>
</div>
<?php footerHtml(); ?>
