<?php require_once 'includes.php'; requireStudent();
$q=trim($_GET['q']??'');
if($q){
    $stmt=$pdo->prepare("SELECT * FROM courses WHERE course_code LIKE ? OR course_name LIKE ? OR faculty LIKE ? ORDER BY course_code");
    $like="%$q%"; $stmt->execute([$like,$like,$like]);
} else { $stmt=$pdo->query("SELECT * FROM courses ORDER BY course_code"); }
$courses=$stmt->fetchAll();
$mine=$pdo->prepare("SELECT course_id FROM enrollments WHERE student_id=?"); $mine->execute([$_SESSION['student_id']]);
$enrolled=array_column($mine->fetchAll(),'course_id');
headerHtml('Courses');
?>
<div class="d-flex justify-content-between align-items-center mb-3"><h2>Available Courses</h2><a href="my_enrollments.php" class="btn btn-success me-2">My Enrollments</a>
<form class="d-flex"><input class="form-control me-2" name="q" value="<?=e($q)?>" placeholder="Search"><button class="btn btn-outline-primary">Search</button></form></div>
<div class="row g-4">
<?php foreach($courses as $c): ?>
<div class="col-md-6"><div class="card p-4">
<h5><?=e($c['course_code'])?> - <?=e($c['course_name'])?></h5>
<p><?=e($c['description'])?></p>
<p><b>Credits:</b> <?=e($c['credits'])?> | <b>Faculty:</b> <?=e($c['faculty'])?></p>
<?php if(in_array($c['course_id'],$enrolled)): ?><span class="badge bg-success">Enrolled</span>
<?php else: ?><a class="btn btn-primary" href="enroll.php?id=<?=$c['course_id']?>">Enroll</a><?php endif; ?>
</div></div>
<?php endforeach; ?>
</div>
<?php footerHtml(); ?>
