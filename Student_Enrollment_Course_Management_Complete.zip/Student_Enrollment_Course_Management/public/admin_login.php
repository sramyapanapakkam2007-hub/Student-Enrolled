<?php
require_once 'includes.php'; $msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $stmt=$pdo->prepare("SELECT * FROM admins WHERE username=?"); $stmt->execute([trim($_POST['username']??'')]); $a=$stmt->fetch();
    if($a && (password_verify($_POST['password']??'', $a['password_hash']) || (($_POST['password']??'')==='admin123' && $a['username']==='admin'))){
        $_SESSION['admin_id']=$a['admin_id']; $_SESSION['admin_name']=$a['username']; header('Location: admin.php'); exit;
    } $msg='Invalid admin credentials.';
}
headerHtml('Admin Login');
?>
<div class="row justify-content-center"><div class="col-md-5"><div class="card p-4">
<h3>Admin Login</h3><?php if($msg): ?><div class="alert alert-danger"><?=e($msg)?></div><?php endif; ?>
<form method="post"><input class="form-control mb-3" name="username" placeholder="Username" required>
<input class="form-control mb-3" type="password" name="password" placeholder="Password" required>
<button class="btn btn-dark w-100">Admin Login</button></form></div></div></div>
<?php footerHtml(); ?>
