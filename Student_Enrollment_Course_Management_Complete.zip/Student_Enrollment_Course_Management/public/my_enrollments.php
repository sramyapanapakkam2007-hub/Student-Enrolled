<?php require_once 'includes.php'; requireStudent();
$stmt=$pdo->prepare("SELECT e.*,c.course_code,c.course_name,c.credits,c.faculty FROM enrollments e JOIN courses c ON c.course_id=e.course_id WHERE e.student_id=? ORDER BY e.enrollment_date DESC");
$stmt->execute([$_SESSION['student_id']]); $rows=$stmt->fetchAll(); headerHtml('My Enrollments');
?>
<h2>My Enrollments</h2>
<table class="table table-bordered bg-white"><thead><tr><th>Code</th><th>Course</th><th>Credits</th><th>Faculty</th><th>Status</th><th>Date</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?=e($r['course_code'])?></td><td><?=e($r['course_name'])?></td><td><?=e($r['credits'])?></td><td><?=e($r['faculty'])?></td><td><?=e($r['status'])?></td><td><?=e($r['enrollment_date'])?></td></tr><?php endforeach; ?>
</tbody></table>
<a href="courses.php" class="btn btn-primary">Enroll in Another Course</a>
<?php footerHtml(); ?>
