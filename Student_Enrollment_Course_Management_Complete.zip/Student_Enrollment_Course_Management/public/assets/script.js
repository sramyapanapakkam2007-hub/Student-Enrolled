function confirmDelete(message) { return confirm(message || 'Are you sure?'); }
