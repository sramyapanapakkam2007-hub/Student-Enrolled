<?php require_once 'includes.php'; requireAdmin();
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    if($action==='save'){
        $id=(int)($_POST['course_id']??0);
        $data=[trim($_POST['course_code']),trim($_POST['course_name']),trim($_POST['description']), (int)$_POST['credits'],trim($_POST['faculty']),(int)$_POST['capacity']];
        try {
            if($id){
                $stmt=$pdo->prepare("UPDATE courses SET course_code=?,course_name=?,description=?,credits=?,faculty=?,capacity=? WHERE course_id=?");
                $stmt->execute([...$data,$id]);
            } else {
                $stmt=$pdo->prepare("INSERT INTO courses(course_code,course_name,description,credits,faculty,capacity) VALUES(?,?,?,?,?,?)");
                $stmt->execute($data);
            }
            header('Location: admin_courses.php'); exit;
        } catch(PDOException $e) { $msg='Course code may already exist.'; }
    }
    if($action==='delete'){
        $stmt=$pdo->prepare("DELETE FROM courses WHERE course_id=?");
        $stmt->execute([(int)$_POST['course_id']]);
        header('Location: admin_courses.php'); exit;
    }
}
$edit=null;
if(isset($_GET['edit'])){
    $stmt=$pdo->prepare("SELECT * FROM courses WHERE course_id=?");
    $stmt->execute([(int)$_GET['edit']]); $edit=$stmt->fetch();
}
$courses=$pdo->query("SELECT * FROM courses ORDER BY course_code")->fetchAll();
headerHtml('Manage Courses'); ?>
<div class="row g-4">
<div class="col-md-5"><div class="card p-4"><h4><?= $edit?'Edit':'Add' ?> Course</h4>
<?php if($msg): ?><div class="alert alert-danger"><?=e($msg)?></div><?php endif; ?>
<form method="post"><input type="hidden" name="action" value="save"><input type="hidden" name="course_id" value="<?=e($edit['course_id']??0)?>">
<input class="form-control mb-2" name="course_code" placeholder="Course Code" value="<?=e($edit['course_code']??'')?>" required>
<input class="form-control mb-2" name="course_name" placeholder="Course Name" value="<?=e($edit['course_name']??'')?>" required>
<textarea class="form-control mb-2" name="description" placeholder="Description"><?=e($edit['description']??'')?></textarea>
<input class="form-control mb-2" type="number" name="credits" placeholder="Credits" value="<?=e($edit['credits']??3)?>" required>
<input class="form-control mb-2" name="faculty" placeholder="Faculty" value="<?=e($edit['faculty']??'')?>">
<input class="form-control mb-3" type="number" name="capacity" placeholder="Capacity" value="<?=e($edit['capacity']??50)?>">
<button class="btn btn-primary">Save Course</button> <a href="admin_courses.php" class="btn btn-secondary">Clear</a>
</form></div></div>
<div class="col-md-7"><div class="card p-4"><h4>Course List</h4><table class="table"><tr><th>Code</th><th>Name</th><th>Action</th></tr>
<?php foreach($courses as $c): ?><tr><td><?=e($c['course_code'])?></td><td><?=e($c['course_name'])?></td><td><a class="btn btn-sm btn-outline-primary" href="?edit=<?=$c['course_id']?>">Edit</a>
<form method="post" class="d-inline" onsubmit="return confirm('Delete this course?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="course_id" value="<?=$c['course_id']?>"><button class="btn btn-sm btn-outline-danger">Delete</button></form></td></tr><?php endforeach; ?>
</table></div></div></div>
<?php footerHtml(); ?>
