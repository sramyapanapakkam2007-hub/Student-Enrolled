<?php require_once 'includes.php'; requireAdmin();
$students=$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$courses=$pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();
$enrollments=$pdo->query("SELECT COUNT(*) FROM enrollments")->fetchColumn();
$rows=$pdo->query("SELECT e.enrollment_id,s.name,s.email,c.course_code,c.course_name,e.status,e.enrollment_date FROM enrollments e JOIN students s ON s.student_id=e.student_id JOIN courses c ON c.course_id=e.course_id ORDER BY e.enrollment_date DESC LIMIT 20")->fetchAll();
headerHtml('Admin Dashboard'); ?>
<h2>Admin Dashboard</h2>
<div class="row g-3 mb-4">
<div class="col-md-4"><div class="card p-4"><div class="stat"><?=e($students)?></div>Students</div></div>
<div class="col-md-4"><div class="card p-4"><div class="stat"><?=e($courses)?></div>Courses</div></div>
<div class="col-md-4"><div class="card p-4"><div class="stat"><?=e($enrollments)?></div>Enrollments</div></div>
</div>
<div class="mb-3"><a class="btn btn-primary" href="admin_courses.php">Manage Courses</a></div>
<h4>Recent Enrollments</h4>
<table class="table table-bordered bg-white"><thead><tr><th>Student</th><th>Email</th><th>Course</th><th>Status</th><th>Date</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?=e($r['name'])?></td><td><?=e($r['email'])?></td><td><?=e($r['course_code'])?> - <?=e($r['course_name'])?></td><td><?=e($r['status'])?></td><td><?=e($r['enrollment_date'])?></td></tr><?php endforeach; ?>
</tbody></table>
<?php footerHtml(); ?>
