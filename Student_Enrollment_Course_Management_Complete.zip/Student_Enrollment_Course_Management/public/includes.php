<?php
session_start();
require_once __DIR__ . '/../config/db.php';

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function requireStudent() {
    if (empty($_SESSION['student_id'])) {
        header('Location: login.php');
        exit;
    }
}
function requireAdmin() {
    if (empty($_SESSION['admin_id'])) {
        header('Location: admin_login.php');
        exit;
    }
}
function headerHtml($title='Student Enrollment System') {
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
<div class="container">
<a class="navbar-brand" href="index.php">SECM</a>
<div>
<?php if (!empty($_SESSION['student_id'])): ?>
<a class="btn btn-outline-light btn-sm me-1" href="dashboard.php">Dashboard</a>
<a class="btn btn-outline-light btn-sm me-1" href="courses.php">Courses</a>
<a class="btn btn-warning btn-sm" href="logout.php">Logout</a>
<?php elseif (!empty($_SESSION['admin_id'])): ?>
<a class="btn btn-outline-light btn-sm me-1" href="admin.php">Admin Dashboard</a>
<a class="btn btn-warning btn-sm" href="admin_logout.php">Logout</a>
<?php else: ?>
<a class="btn btn-outline-light btn-sm me-1" href="login.php">Student Login</a>
<a class="btn btn-light btn-sm" href="register.php">Register</a>
<?php endif; ?>
</div></div></nav>
<main class="container py-4">
<?php
}
function footerHtml() {
?>
</main><footer><div class="container text-center">Student Enrollment & Course Management System</div></footer>
</body></html>
<?php } ?>
