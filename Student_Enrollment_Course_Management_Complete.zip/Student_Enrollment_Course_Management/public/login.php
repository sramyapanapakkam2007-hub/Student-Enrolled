<?php
require_once 'includes.php'; $msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $stmt=$pdo->prepare("SELECT * FROM students WHERE email=?"); $stmt->execute([trim($_POST['email']??'')]);
    $s=$stmt->fetch();
    if($s && password_verify($_POST['password']??'', $s['password_hash'])){
        $_SESSION['student_id']=$s['student_id']; $_SESSION['student_name']=$s['name'];
        header('Location: dashboard.php'); exit;
    } $msg='Invalid email or password.';
}
headerHtml('Student Login');
?>
<div class="row justify-content-center"><div class="col-md-5"><div class="card p-4">
<h3>Student Login</h3>
<?php if(isset($_GET['registered'])): ?><div class="alert alert-success">Registration successful. Please log in.</div><?php endif; ?>
<?php if($msg): ?><div class="alert alert-danger"><?=e($msg)?></div><?php endif; ?>
<form method="post">
<input class="form-control mb-3" type="email" name="email" placeholder="Email" required>
<input class="form-control mb-3" type="password" name="password" placeholder="Password" required>
<button class="btn btn-primary w-100">Login</button>
</form></div></div></div>
<?php footerHtml(); ?>
