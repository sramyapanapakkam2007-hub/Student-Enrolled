<?php
require_once 'includes.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim($_POST['name']??''); $email=trim($_POST['email']??'');
    $phone=trim($_POST['phone']??''); $dept=trim($_POST['department']??'');
    $year=(int)($_POST['year_level']??0); $password=$_POST['password']??'';
    if (!$name || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<6) {
        $msg='Please enter valid details. Password must contain at least 6 characters.';
    } else {
        try {
            $stmt=$pdo->prepare("INSERT INTO students(name,email,phone,department,year_level,password_hash) VALUES(?,?,?,?,?,?)");
            $stmt->execute([$name,$email,$phone,$dept,$year,password_hash($password,PASSWORD_DEFAULT)]);
            header('Location: login.php?registered=1'); exit;
        } catch(PDOException $e) { $msg='Email already exists or registration failed.'; }
    }
}
headerHtml('Student Registration');
?>
<div class="row justify-content-center"><div class="col-md-7"><div class="card p-4">
<h3>Student Registration</h3>
<?php if($msg): ?><div class="alert alert-danger"><?=e($msg)?></div><?php endif; ?>
<form method="post">
<input class="form-control mb-3" name="name" placeholder="Full Name" required>
<input class="form-control mb-3" type="email" name="email" placeholder="Email" required>
<input class="form-control mb-3" name="phone" placeholder="Phone">
<input class="form-control mb-3" name="department" placeholder="Department">
<input class="form-control mb-3" type="number" name="year_level" min="1" max="6" placeholder="Year">
<input class="form-control mb-3" type="password" name="password" placeholder="Password (min 6 characters)" required>
<button class="btn btn-primary">Create Account</button>
</form></div></div></div>
<?php footerHtml(); ?>
