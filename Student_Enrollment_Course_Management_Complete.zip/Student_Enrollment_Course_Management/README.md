# Student Enrollment and Course Management System

A beginner-friendly web application for managing students, courses, and course enrollments.

## Technology
- PHP 8+
- MySQL 8+
- HTML5, CSS3, JavaScript
- Bootstrap 5 CDN

## Features
- Student registration and login
- Student dashboard
- Browse and search courses
- Enroll in courses
- View enrollment status
- Admin login
- Add, edit, delete courses
- View students and enrollments
- Simple dashboard statistics

## Demo credentials
Admin:
- Username: admin
- Password: admin123

Students can create their own account.

## Installation
1. Install XAMPP/WAMP/LAMP.
2. Copy the `public` folder and the `config` folder into your web server project directory, keeping the same structure.
3. Create a MySQL database named `student_enrollment`.
4. Import `database/database.sql` using phpMyAdmin.
5. Edit `config/db.php` if your MySQL username/password is different.
6. Open:
   http://localhost/Student_Enrollment_Course_Management/public/

## Suggested XAMPP layout
htdocs/
└── Student_Enrollment_Course_Management/
    ├── config/
    ├── database/
    └── public/

## Project phases
Phase 1: Requirements
Phase 2: System Design
Phase 3: Database Design
Phase 4: Development
Phase 5: Testing
Phase 6: Documentation

See the `docs` folder for phase-wise documents.
