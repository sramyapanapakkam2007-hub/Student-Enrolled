# Test Cases
| ID | Test Case | Expected Result |
|---|---|---|
| TC01 | Open home page | Home page loads |
| TC02 | Register with valid data | Student account is created |
| TC03 | Register with duplicate email | Error is shown |
| TC04 | Login with valid credentials | Dashboard opens |
| TC05 | Login with invalid credentials | Error is shown |
| TC06 | Search course | Matching courses display |
| TC07 | Enroll in course | Enrollment is recorded |
| TC08 | Enroll in same course twice | Duplicate enrollment is prevented |
| TC09 | Admin login | Admin dashboard opens |
| TC10 | Add course | Course appears |
| TC11 | Edit course | Updated data displays |
| TC12 | Delete course | Course is removed |
| TC13 | Logout | Session ends |
