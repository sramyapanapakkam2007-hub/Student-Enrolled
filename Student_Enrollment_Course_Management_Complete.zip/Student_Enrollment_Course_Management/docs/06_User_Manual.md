# User Manual
## Student
1. Open the application.
2. Select Student Registration.
3. Enter details and create an account.
4. Log in.
5. Select Courses.
6. Search or browse courses.
7. Click Enroll.
8. Open My Enrollments.

## Administrator
1. Select Admin Login.
2. Username: `admin`
3. Password: `admin123`
4. View dashboard statistics.
5. Select Manage Courses.
6. Add, edit or delete courses.

## Troubleshooting
- Start Apache and MySQL in XAMPP.
- Check `config/db.php` if the database connection fails.
- Import `database/database.sql` through phpMyAdmin.
