# Project Proposal
## Title
Student Enrollment and Course Management System

## Problem Statement
Manual student enrollment and course records can lead to duplicate entries, slow searching, and difficulty tracking enrollment status.

## Objectives
- Provide online student registration.
- Maintain course information.
- Allow students to browse and enroll in courses.
- Provide an admin dashboard.
- Store records in a centralized relational database.

## Scope
The system covers student accounts, course catalog, enrollment records, and basic administration. Payment, attendance, examination and external ERP integration are outside the current scope.

## Users
1. Student
2. Administrator

## Expected Outcome
A simple web application that reduces manual enrollment work and provides searchable, organized records.
