# Phase-Wise Project Documents
## Phase 1 - Requirement Analysis
Deliverables: Project Proposal, SRS.

## Phase 2 - System Design
Deliverable: System Design, architecture and UML/use-case descriptions.

## Phase 3 - Database Design
Deliverable: database.sql and Database Design.

## Phase 4 - Development
Deliverable: PHP, HTML, CSS and JavaScript source code.

## Phase 5 - Testing
Deliverable: Test Cases.

## Phase 6 - Documentation
Deliverables: User Manual and Final Report.
