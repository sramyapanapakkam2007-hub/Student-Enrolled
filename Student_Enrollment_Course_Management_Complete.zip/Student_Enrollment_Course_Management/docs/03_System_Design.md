# System Design
## Architecture
Browser -> PHP Web Application -> MySQL Database

## Modules
- Authentication
- Student Management
- Course Management
- Enrollment Management
- Admin Dashboard

## Data Flow
Student -> Login -> Course Search -> Course Selection -> Enrollment -> Database
Admin -> Login -> Course Management -> Database -> Dashboard

## ER Relationship
Students 1 --- N Enrollments N --- 1 Courses
Admins manage Courses.

## UML Use Cases
Student: Register, Login, View Courses, Search Courses, Enroll, View Enrollments
Admin: Login, Add Course, Edit Course, Delete Course, View Enrollment Dashboard
