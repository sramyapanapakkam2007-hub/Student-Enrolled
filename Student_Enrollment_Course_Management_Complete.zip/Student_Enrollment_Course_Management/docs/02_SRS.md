# Software Requirements Specification (SRS)
## Functional Requirements
FR1: Student shall register with name, email, phone, department, year and password.
FR2: Student shall log in securely.
FR3: Student shall view and search courses.
FR4: Student shall enroll in an available course.
FR5: Student shall view previous enrollments.
FR6: Admin shall log in.
FR7: Admin shall add, edit and delete courses.
FR8: Admin shall view dashboard statistics and recent enrollments.

## Non-Functional Requirements
- Usable through a modern web browser.
- Passwords are stored using password hashing.
- SQL statements use prepared queries.
- Database maintains referential integrity.
- Interface should be responsive.

## Hardware Requirements
Computer with 4 GB RAM or higher and 2 GB free disk space.

## Software Requirements
XAMPP/WAMP/LAMP, PHP 8+, MySQL 8+, Chrome/Firefox/Edge.
