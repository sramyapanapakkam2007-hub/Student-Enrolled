# Database Design
## students
student_id (PK), name, email (UNIQUE), phone, department, year_level, password_hash, created_at

## admins
admin_id (PK), username (UNIQUE), password_hash

## courses
course_id (PK), course_code (UNIQUE), course_name, description, credits, faculty, capacity, created_at

## enrollments
enrollment_id (PK), student_id (FK), course_id (FK), enrollment_date, status

## Normalization
Student, course and enrollment data are separated. Enrollment uses foreign keys rather than repeating student/course details, reducing update anomalies.
