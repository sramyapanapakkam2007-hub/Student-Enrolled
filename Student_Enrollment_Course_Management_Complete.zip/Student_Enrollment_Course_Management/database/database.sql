CREATE DATABASE IF NOT EXISTS student_enrollment
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE student_enrollment;

CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20),
    department VARCHAR(100),
    year_level INT,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE admins (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL
);

CREATE TABLE courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(30) NOT NULL UNIQUE,
    course_name VARCHAR(150) NOT NULL,
    description TEXT,
    credits INT DEFAULT 3,
    faculty VARCHAR(100),
    capacity INT DEFAULT 50,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Pending','Approved','Rejected') DEFAULT 'Approved',
    UNIQUE KEY unique_enrollment (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

INSERT INTO admins (username, password_hash)
VALUES ('admin', '$2y$10$7EqJtq98hPqEX7fNZaFWoO6Z4QJ9pK9M9f6Q0v5w2mJx5Yf9Jr7QW');

INSERT INTO courses (course_code, course_name, description, credits, faculty, capacity) VALUES
('CS101','Introduction to Computer Science','Fundamentals of computing and problem solving.',4,'Computer Science',60),
('DBMS201','Database Management Systems','Relational databases, SQL and database design.',4,'Computer Science',60),
('SE301','Software Engineering','Software development life cycle, design and testing.',3,'Computer Science',50),
('DM401','Data Mining','Data preprocessing, classification and clustering.',4,'Computer Science',50),
('WEB205','Web Development','HTML, CSS, JavaScript and server-side web programming.',3,'Computer Science',60);
